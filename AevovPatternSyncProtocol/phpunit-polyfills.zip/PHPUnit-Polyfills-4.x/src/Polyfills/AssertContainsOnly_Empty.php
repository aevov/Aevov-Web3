<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 11.5.0 in which the polyfill is not needed.
 *
 * @since 3.1.0
 */
trait AssertContainsOnly {}
