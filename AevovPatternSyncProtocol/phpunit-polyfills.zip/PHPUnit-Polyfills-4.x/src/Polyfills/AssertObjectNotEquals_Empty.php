<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 11.2.0 in which this polyfill is not needed.
 *
 * @since 3.0.0
 */
trait AssertObjectNotEquals {}
