<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 10.0.0 in which this polyfill is not needed.
 *
 * @since 2.0.0
 */
trait AssertIgnoringLineEndings {}
