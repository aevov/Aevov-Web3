<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 9.6.11 < 10.0.0 and PHPUnit >= 10.1.0 in which this polyfill is not needed.
 *
 * @since 2.0.0
 */
trait AssertObjectProperty {}
