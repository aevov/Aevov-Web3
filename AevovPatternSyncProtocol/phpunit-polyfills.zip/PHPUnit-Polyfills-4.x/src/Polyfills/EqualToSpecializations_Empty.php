<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 9.0.0 in which this polyfill is not needed.
 *
 * @since 1.0.0
 */
trait EqualToSpecializations {}
