<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 11.0.0 in which the polyfill is not needed.
 *
 * @since 3.0.0
 */
trait AssertArrayWithListKeys {}
