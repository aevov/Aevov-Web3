<?php

namespace Yoast\PHPUnitPolyfills\Polyfills;

/**
 * Empty trait for use with PHPUnit >= 8.4.0 in which this polyfill is not needed.
 *
 * @since 0.1.0
 */
trait ExpectExceptionMessageMatches {}
